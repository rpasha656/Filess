var gulp = require('gulp');
var util = require('gulp-util');
var runSequence = require('run-sequence');
var config = require('../config')();
var useref = require('gulp-useref');
var gulpif = require('gulp-if');
var rev = require('gulp-rev');
var revReplace = require('gulp-rev-replace');
var uglify = require('gulp-uglify');
var cssnano = require('gulp-cssnano');
var gulpTemplate = require('gulp-template');
var envVars = require('../utils/env-vars');
var vendorNpmFiles = require('../vendor-npm.config');
var assetFiles = config.src + '**/*.+(html|js|css|png|eot|svg|ttf|woff|jpg|gif|pdf|scss)';
var Builder = require('systemjs-builder');
var argv = require('yargs').argv;

function bundle(done) {
    done = done || function () { };
    return function () {
        if (!argv.prod) {
            util.log('Skipping bundle');
            done();
        } else {
            //Run 
            var builder = new Builder({
                baseURL: config.tmp
            });
            builder.loadConfig(config.tmp + config.systemJs.configFileName)
                .then(function () {
                    return builder.bundle('main.js', config.tmp + 'main.js', config.systemJs.builder);
                })
                .then(function () {
                    util.log('Build complete');
                    done();
                })
                .catch(function (ex) {
                    util.log('Build failed', ex);
                    done('Build failed.');
                });
        }
    }
}

gulp.task('build', [], function (done) {
    runSequence('clean-build', 'copy-files', 'sass', 'tsc-app', 'bundle-references', bundle(done));
});

gulp.task('env', function () {
    return gulp.src(config.config + 'env/env.ts')
        .pipe(gulpTemplate({
            env: envVars || {}
        }))
        .pipe(gulp.dest(config.app + 'shared/constant'))
        .on('finish', function () {
            util.log(config.app + 'shared/constant/env.ts is generated successfully');
        });
});

/* Copy index and loose .js files */
gulp.task('copy-files', ['copy-vendor', 'copy-assets']);

gulp.task('copy-vendor', function (done) {

    gulp.src(config.vendorNpmFiles, { base: config.nodeRoot })
        .pipe(gulp.dest(config.tmp + "vendor"))
        .on('finish', function () {
            if (!argv.prod) {
                util.log('Skipping copy-vendor-fonts');
                done();
            } else {
                console.log('copy  vendor fonts')
                gulp.src(config.fontFiles)
                    .pipe(gulp.dest(config.tmp + "fonts"))
                    .on('finish', done);
            }
        });
});
gulp.task('copy-assets', function (done) {
    gulp.src(assetFiles, { base: config.src })
        .pipe(gulp.dest(config.tmp))
        .on('finish', done);
});

gulp.task('watch-files', function () {
    gulp.watch(assetFiles, ['copy-files']);
    gulp.watch(config.tsFiles, function () {
        runSequence('tsc-app', bundle())
    });
});

gulp.task('bundle-references', function (done) {

    if (!argv.prod || !config.index) {
        console.log('skipping bundle-references');
        done();
    } else {
        gulp.src(config.index)
            .pipe(useref())
            .pipe(gulp.dest(config.tmp))
            .on('finish', done);
    }
});

gulp.task('copy-vendor-fonts', function (done) {
    if (!argv.prod) {
        util.log('Skipping copy-vendor-fonts');
        done();
    } else {
        gulp.src(config.fontFiles)
            .pipe(gulp.dest(config.tmp + "fonts"))
            .on('finish', done);
    }
})